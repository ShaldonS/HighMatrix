#pragma once
#include "TVector.h"

template <class T> 
class TMatrix : public TVector<TVector<T>>
{
private:
public:

	TMatrix(int Size = 5) : TVector<TVector<T>>(Size)
	{
		for (int i = 0; i < Size; i++)
			this->pVector[i] = TVector<T>(Size);
	}

	TVector<T>& operator[] (int i)
	{
		return this->pVector[i];
	}

	~TMatrix() 
	{
		delete[] this->pVector;
	}

	TMatrix(const TMatrix& mt) : TVector<TVector<T>>(mt) {}
	TMatrix(const TVector<TVector<T>>& mt) : TVector<TVector<T>>(mt) {}
	TMatrix& operator==(const TMatrix& mt); // ���������
	TMatrix operator= (const TMatrix& mt); // ������������
	TMatrix operator+ (const TMatrix& mt); // ��������
	TMatrix operator- (const TMatrix& mt); // ���������
	TMatrix operator* (const TMatrix& mt); // ���������

	// ���� / �����
	friend istream& operator>>(istream& in, TMatrix<T>& mt)
	{
		for (int i(0); i < mt.Size; i++)
		{
			cout << "\nInput v[" << i << "]: ";
			cin >> mt.pVector[i];
		}
		return in;
	}

	friend ostream& operator<<(ostream& out, const TMatrix<T>& mt)
	{
		for (int i(0); i < mt.Size; i++)
		{
				out << mt.pVector[i];
		}
		return out;
	}
};

template <class T>
TMatrix<T> TMatrix<T>::operator+(const TMatrix<T>& mt)
{
	return TVector<TVector<T>>::operator+(mt);
}

template <class T>
TMatrix<T> TMatrix<T>::operator-(const TMatrix<T>& mt)
{
	return TVector<TVector<T>>::operator-(mt);
}

template <class T>
TMatrix<T> TMatrix<T>::operator*(const TMatrix<T>& mt)
{
	TMatrix<T> Matr(mt.Size);
	for (int i = 0; i < this->Size; ++i)
	{
		for (int j = 0; j < this->Size; ++j)
		{		
			for (int k = 0; k < this->Size; ++k)
				Matr.pVector[i][j] = Matr.pVector[i][j] + mt.pVector[i][k] * mt.pVector[k][j];
		}
	}

	return Matr;
}

template <class T>
TMatrix<T> TMatrix<T>::operator=(const TMatrix<T>& mt)
{
	/*if (this != &mt)
	{
		if (this->Size != mt.Size)
		{
			delete[] this->pVector;
			this->pVector = new TVector<T>[mt.Size];
		}
		this->Size = mt.Size;
		for (int i = 0; i < this->Size; i++)
			this->pVector[i] = mt.pVector[i];
	}
	return *this;*/
	return TVector<TVector<T>>::operator=(mt);
}
