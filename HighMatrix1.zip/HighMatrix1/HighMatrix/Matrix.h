#pragma once
#include "Vector.h"

template <class T>
class TMatrix : public TVector<TVector<T>>
{
private:
	int size;
	TVector<T>* pVector;
public:

	TMatrix(int Size) : TVector<TVector<T>>(Size)
	{
		for(int i(0); i < Size; i++)
			pVector[i] = TVector<T>(Size);
	}

	TVector<T>& operator[] (int i)
	{
		return pVector[i];
	}

	~TMatrix() {
		delete[] pVector;
	}

	TMatrix(const TMatrix& mt) : TVector<TVector<T>>(mt) {}
	TMatrix(const TVector<TVector<T>>& mt) : TVector<TVector<T>>(mt) {}
	TMatrix& operator==(const TMatrix& mt); // ���������
	TMatrix& operator= (const TMatrix& mt); // ������������
	TMatrix operator+ (const TMatrix& mt); // ��������
	TMatrix operator- (const TMatrix& mt); // ���������
	TMatrix operator* (const TMatrix& mt); // ���������

	// ���� / �����
	friend istream& operator>>(istream& in, TMatrix<T>& mt)
	{
		for (int i(0); i < mt.size; i++)
		{
			cout << "\nInput v[" << i << "]: ";
			cin >> mt.pVector[i];
		}
		return in;
	}

	friend ostream& operator<<(ostream& out, const TMatrix<T>& mt)
	{
		for (int i(0); i < mt.size; i++)
		{
			out << " " << mt.pVector[i] << endl;
		}
		return out;
	}
};

template <class T>
TMatrix<T> TMatrix<T>::operator+(const TMatrix<T>& mt)
{
	return TVector<TVector<T>>::operator+(mt);
}

template <class T>
TMatrix<T> TMatrix<T>::operator-(const TMatrix<T>& mt)
{
	return TVector<TVector<T>>::operator-(mt);
}

template <class T>
TMatrix<T> TMatrix<T>::operator*(const TMatrix<T>& mt)
{
	//return TVector<TVector<ValType>>::operator*(mt);
}

template <class T>
TMatrix<T>& TMatrix<T>::operator=(
	const TMatrix<T>& mt)
{
	if (this != &mt)
	{
		if (size != mt.size)
		{
			delete[] pVector;
			pVector = new TVector<T>[mt.Size];
		}
		size = mt.size;
		for (int i = 0; i < size; i++)
			pVector[i] = mt.pVector[i];
	}
	return *this;
}
