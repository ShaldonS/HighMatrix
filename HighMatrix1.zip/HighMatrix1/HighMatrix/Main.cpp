#define _CRT_SECURE_NO_WARNINGS
#include "HighMatrix.h"

int main(int argc, char* argv[])
{

	TMatrix<int> a(5), b(5), c(5);


	for (int i(0); i < 5; i++)
	{
		for (int j(i); j < 5; j++)
		{
			a[i][j] = i * 10 + j;
			b[i][j] = (i * 10 + j) * 100;
		}
	}

	cout << "\na: \n" << a;

	cout << "\nb: \n" << b;

	c = a-b;
	cout << endl << c;
	c = a * b;
	cout << endl << c;
	return 0;
}

